
using Fruits.Common.Entities;
using Fruits.Common.Services;

Apple apple = new Apple("Red", true);
apple.OnFruitEvent += msg => Console.WriteLine("Apple event: " + msg);

Banana banana = new Banana("Yellow", 20);
banana.OnFruitEvent += msg => Console.WriteLine("Banana event: " + msg);

Orange orange = new Orange("Orange", 70);
orange.OnFruitEvent += msg => Console.WriteLine("Orange event: " + msg);

apple.DisplayInfo();
apple.Eat();

banana.DisplayInfo();
banana.Eat();

orange.DisplayInfo();
orange.Eat();

Console.WriteLine($"Total fruits created: {Fruit.TotalFruitsCreated}");

var service = new CrudService<Apple>(f => f.Id);
// Create
service.Create(apple);

Console.WriteLine("All fruits after creation:");
foreach (var fruit in service.ReadAll())
    Console.WriteLine($"{fruit.Name} ({fruit.Color})");

// Update
apple.Color = "Green";
service.Update(apple);

Console.WriteLine("\nAll fruits after update:");
foreach (var fruit in service.ReadAll())
    Console.WriteLine($"{fruit.Name} ({fruit.Color})");

// Save to file
string path = "fruits.json";
service.Save(path);
Console.WriteLine($"\nSaved to {path}");

// Clear and load again
var newService = new CrudService<Apple>(f => f.Id);
newService.Load(path);

Console.WriteLine("\nFruits after loading from file:");
foreach (var fruit in newService.ReadAll())
    Console.WriteLine($"{fruit.Name} ({fruit.Color})");

// Remove
newService.Remove(apple);
Console.WriteLine("\nAfter removing A[[;e:");
foreach (var fruit in newService.ReadAll())
    Console.WriteLine($"{fruit.Name} ({fruit.Color})");