using Fruits.Common.Contracts;
using Fruits.Common.Extensions;
using Newtonsoft.Json;

namespace Fruits.Common.Services;

public class CrudService<T> : ICrudService<T>
{
    private readonly Func<T, Guid> _idGetter;
    private Dictionary<Guid, T> _dictionary = new();

    public CrudService(Func<T, Guid> idGetter)
    {
        _idGetter = idGetter;
    }
    
    public void Create(T element)
    {
        _dictionary.TryAdd(_idGetter(element), element);
    }

    public T Read(Guid id)
    {
        return _dictionary.TryGetValue(id, out T element) ? element : default;
    }

    public IEnumerable<T> ReadAll()
    {
        return _dictionary.Values;
    }

    public void Update(T element)
    {
        _dictionary[_idGetter(element)] = element;
    }

    public void Remove(T element)
    {
        _dictionary.Remove(_idGetter(element));
    }

    public void Save(string path)
    {
        try
        {
            var json = _dictionary.ToJson();
            File.WriteAllText(path, json);
        }
        catch (Exception exception)
        {
            Console.WriteLine(exception.Message);
        }
    }

    public void Load(string path)
    {
        try
        {
            var json = File.ReadAllText(path);
            _dictionary = JsonConvert.DeserializeObject<Dictionary<Guid, T>>(json)!;
        }
        catch (Exception exception)
        {
            Console.WriteLine(exception.Message);
        }
    }
}