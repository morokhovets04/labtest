using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace Fruits.Common.Extensions;

// Static class for extensions
public static class ObjectExtensions
{
    public static string ToJson(this object @object)
    {
        return JsonConvert.SerializeObject(@object, Formatting.Indented);
    }
}