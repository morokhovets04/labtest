namespace Fruits.Common.Entities;

// Child class: Orange
public class Orange : Fruit
{
    public int VitaminCContentMg { get; }

    static Orange()
    {
        Console.WriteLine("Static constructor of Orange called.");
    }

    public Orange(string color, int vitaminCContentMg) 
        : base("Orange", color)
    {
        VitaminCContentMg = vitaminCContentMg;
        OnFruitEvent?.Invoke($"Orange vitamin C content: {VitaminCContentMg} mg.");
    }

    public override void Eat()
    {
        Console.WriteLine("You peel the orange and enjoy juicy segments.");
    }

    public override void DisplayInfo()
    {
        base.DisplayInfo();
        Console.WriteLine($"Vitamin C content: {VitaminCContentMg} mg");
    }
}