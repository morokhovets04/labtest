namespace Fruits.Common.Entities;

// Child class: Apple
public class Apple : Fruit
{
    public bool IsSour { get; }

    static Apple()
    {
        Console.WriteLine("Static constructor of Apple called.");
    }

    public Apple(string color, bool isSour) 
        : base("Apple", color)
    {
        IsSour = isSour;
        OnFruitEvent?.Invoke($"Apple is {(IsSour ? "sour" : "sweet")}.");
    }

    public override void Eat()
    {
        Console.WriteLine("You bite the apple. Crunchy!");
    }

    public override void DisplayInfo()
    {
        base.DisplayInfo();
        Console.WriteLine($"Is sour? {IsSour}");
    }
}