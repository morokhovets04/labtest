namespace Fruits.Common.Entities;

// Child class: Banana
public class Banana : Fruit
{
    public int LengthCm { get; }

    static Banana()
    {
        Console.WriteLine("Static constructor of Banana called.");
    }

    public Banana(string color, int lengthCm) 
        : base("Banana", color)
    {
        LengthCm = lengthCm;
        OnFruitEvent?.Invoke($"Banana length: {LengthCm} cm.");
    }

    public override void Eat()
    {
        Console.WriteLine("You peel the banana and eat it.");
    }

    public override void DisplayInfo()
    {
        base.DisplayInfo();
        Console.WriteLine($"Length: {LengthCm} cm");
    }
}