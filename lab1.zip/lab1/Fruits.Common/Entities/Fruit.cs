using Newtonsoft.Json;

namespace Fruits.Common.Entities;

// Delegate example: for fruit-related events
public delegate void FruitEventHandler(string message);

// Abstract base class
public abstract class Fruit
{
    // Id
    public Guid Id { get; set; } = Guid.NewGuid();
    
    // Static field shared across all fruits
    public static int TotalFruitsCreated;

    // Instance fields
    public string Name { get; set; }
    public string Color { get; set; }

    // Delegate instance field
    [JsonIgnore]
    public FruitEventHandler? OnFruitEvent;

    // Static constructor
    static Fruit()
    {
        TotalFruitsCreated = 0;
        Console.WriteLine("Static constructor of Fruit called.");
    }

    // Instance constructor
    protected Fruit(string name, string color)
    {
        Name = name;
        Color = color;
        TotalFruitsCreated++;

        OnFruitEvent?.Invoke($"{Name} created!");
    }

    // Abstract method to be implemented by children
    public abstract void Eat();

    // Virtual method (optional override)
    public virtual void DisplayInfo()
    {
        Console.WriteLine($"Fruit: {Name}, Color: {Color}");
    }
}